package com.example.employeemanage.query.FindQuery;

import lombok.Data;

@Data
public class FindAllEmployeeQuery {
    private String employeeId;
}
